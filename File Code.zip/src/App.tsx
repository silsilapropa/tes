/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Leaf, Shield
} from 'lucide-react';
import { Transaction, Courier, IndustryPartner } from './types';
import WebDashboard from './components/WebDashboard';

// Initial Seed Data matching the actual Proposal (e.g. Sectors, Volumes, Partners)
const INITIAL_TRANSACTIONS: Transaction[] = [
  { 
    id: 'SOS-9921', 
    date: '2026-05-25', 
    clientName: 'Restoran Padang Sederhana', 
    clientType: 'UMKM', 
    volume: 25, 
    unit: 'Liter',
    category: 'Oil',
    points: 3750, 
    location: 'Jl. Sudirman No 12, Surakarta', 
    status: 'Pending', 
    assignedCourier: 'Budi Santoso' 
  },
  { 
    id: 'SOS-8801', 
    date: '2026-05-23', 
    clientName: 'Rio Ananda Saleh (Sumbangan)', 
    clientType: 'Rumah Tangga', 
    volume: 12.5, 
    unit: 'Kg',
    category: 'Sampah',
    points: 1250, 
    location: 'Perum Gading Indah Blok C5', 
    status: 'Completed', 
    assignedCourier: 'Marcus Thorne' 
  },
  { 
    id: 'SOS-8742', 
    date: '2026-05-22', 
    clientName: 'Ayam Goreng Pak Slamet', 
    clientType: 'UMKM', 
    volume: 45, 
    unit: 'Liter',
    category: 'Oil',
    points: 6750, 
    location: 'Jl. Slamet Riyadi No. 99', 
    status: 'Completed', 
    assignedCourier: 'Budi Santoso' 
  },
  { 
    id: 'SOS-8521', 
    date: '2026-05-20', 
    clientName: 'Martabak Solo Raya', 
    clientType: 'UMKM', 
    volume: 18, 
    unit: 'Liter',
    category: 'Oil',
    points: 2700, 
    location: 'Pertigaan Badran, Solo', 
    status: 'Completed', 
    assignedCourier: 'Marcus Thorne' 
  },
  { 
    id: 'SOS-8110', 
    date: '2026-05-18', 
    clientName: 'Ibu Pujawati', 
    clientType: 'Rumah Tangga', 
    volume: 6.8, 
    unit: 'Kg',
    category: 'Sampah',
    points: 680, 
    location: 'RT 02 RW 04 Kerten, Surakarta', 
    status: 'Cancelled', 
    assignedCourier: 'Janice' 
  }
];

const INITIAL_COURIERS: Courier[] = [
  { 
    id: 'C-01', 
    name: 'Budi Santoso', 
    phone: '+62-811-9231-4455', 
    status: 'Active', 
    vehicle: 'Motor Tangki Filter', 
    vehiclePlate: 'B 1234 OIL', 
    currentZone: 'Zone B-12', 
    currentLat: 45, 
    currentLng: 32, 
    completedCount: 14 
  },
  { 
    id: 'C-02', 
    name: 'Marcus Thorne', 
    phone: '+62-812-3329-1111', 
    status: 'Idle', 
    vehicle: 'Mobilitas Serap 3 Roda', 
    vehiclePlate: 'AD 9920 DB', 
    currentZone: 'Zone A-05', 
    currentLat: 20, 
    currentLng: 65, 
    completedCount: 32 
  },
  { 
    id: 'C-03', 
    name: 'Janice', 
    phone: '+62-813-8822-7711', 
    status: 'Active', 
    vehicle: 'Pickup Tangki Mini', 
    vehiclePlate: 'AD 4051 SB', 
    currentZone: 'Zone C-09', 
    currentLat: 78, 
    currentLng: 48, 
    completedCount: 8 
  }
];

const INITIAL_INDUSTRY_PARTNERS: IndustryPartner[] = [
  { 
    id: 'IP-01', 
    name: 'PT Pertamina (Persero) Cirebon', 
    sector: 'Biodiesel', 
    allocatedVolume: 28500, 
    activeContracts: 3, 
    efficiency: 88, 
    status: 'Aktif' 
  },
  { 
    id: 'IP-02', 
    name: 'Solo Green BioEnergy Ltd', 
    sector: 'Biodiesel', 
    allocatedVolume: 12000, 
    activeContracts: 1, 
    efficiency: 85, 
    status: 'Aktif' 
  },
  { 
    id: 'IP-03', 
    name: 'PT Sinar Jaya Soap & Wax corp', 
    sector: 'Sabun / Wax', 
    allocatedVolume: 4500, 
    activeContracts: 2, 
    efficiency: 92, 
    status: 'Siaga' 
  }
];

export default function App() {
  // Master cross-functional shared state store
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [couriers, setCouriers] = useState<Courier[]>(INITIAL_COURIERS);
  const [industryPartners, setIndustryPartners] = useState<IndustryPartner[]>(INITIAL_INDUSTRY_PARTNERS);

  // State handlers to ensure clean updates
  const handleAddTransaction = (newTx: Transaction) => {
    setTransactions(prev => [newTx, ...prev]);
  };

  const handleUpdateTxStatus = (txId: string, newStatus: Transaction['status']) => {
    setTransactions(prev => 
      prev.map(tx => tx.id === txId ? { ...tx, status: newStatus } : tx)
    );
  };

  const handleUpdateCourierStatus = (courierId: string, newStatus: Courier['status']) => {
    setCouriers(prev => 
      prev.map(c => c.id === courierId ? { ...c, status: newStatus } : c)
    );
  };

  // Live total collection calculators for two subsystems
  const calculateTotalCollected = () => {
    return transactions
      .filter(t => t.status === 'Completed' && (!t.category || t.category === 'Oil'))
      .reduce((sum, current) => sum + current.volume, 45184.3); // Starting baseline for Oil (approx 45k Liters)
  };

  const calculateTotalSampahCollected = () => {
    return transactions
      .filter(t => t.status === 'Completed' && t.category === 'Sampah')
      .reduce((sum, current) => sum + current.volume, 12840.0); // Starting baseline for Sampah (approx 12.8 Tons)
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col justify-between select-none">
      
      {/* Top Main Navigation Header Banner */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-xs px-4 py-3.5 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row gap-4 items-center justify-between">
          
          {/* Logo Brand Cover */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center p-1.5 shadow-xs">
              <Leaf className="w-5.5 h-5.5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-display font-black text-slate-800 text-base tracking-tight leading-none">ECOSMART SYSTEM</h1>
                <span className="bg-emerald-100 text-emerald-800 text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase">Minyak & Bank Sampah</span>
              </div>
              <p className="text-[10.5px] text-slate-400 font-semibold tracking-wider uppercase mt-0.5">S1-Sistem Informasi • UDB Surakarta</p>
            </div>
          </div>

          {/* Active Navigation Panel Switches - Simplified since Portal Admin is the only dashboard */}
          <div className="flex bg-emerald-50/80 px-3 py-1.5 rounded-xl border border-emerald-100 text-emerald-800 text-xs font-bold items-center gap-1.5 whitespace-nowrap">
            💻 Portal Admin & Industri
          </div>
        </div>
      </header>

      {/* Main Container Content */}
      <main className="flex-1">
        <WebDashboard 
          transactions={transactions}
          addTransaction={handleAddTransaction}
          updateTxStatus={handleUpdateTxStatus}
          couriers={couriers}
          updateCourierStatus={handleUpdateCourierStatus}
          industryPartners={industryPartners}
          totalCollected={calculateTotalCollected()}
          totalSampahCollected={calculateTotalSampahCollected()}
        />
      </main>

      {/* Footnote Copyright academic indicators */}
      <footer className="border-t border-slate-100 bg-white py-6 mt-12 px-4 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between text-xs text-slate-400">
          <div className="text-center md:text-left space-y-1">
            <p className="font-semibold text-slate-700">© 2026 EcoSmart System. Seluruh Hak Cipta Dilindungi.</p>
            <p>Proposal Rilis Kewirausahaan I — Universitas Duta Bangsa Surakarta (UDB)</p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-[10.5px]">
            <span className="flex items-center gap-1 text-slate-500 font-medium">
              <Shield className="w-3.5 h-3.5 text-emerald-500" />
              Sistem Terverifikasi Akademik
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-500 font-bold font-mono text-emerald-600">Level: Green Project</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
