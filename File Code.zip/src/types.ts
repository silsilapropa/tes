/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Transaction {
  id: string;
  date: string;
  clientName: string;
  clientType: 'Rumah Tangga' | 'UMKM' | 'Industri';
  volume: number; // in Liters or Kg depending on category
  unit?: 'Liter' | 'Kg'; // 'Liter' for Oil, 'Kg' for Sampah
  category?: 'Oil' | 'Sampah'; // 'Oil' as default, 'Sampah' for Waste Bank
  points: number;
  location: string;
  industrySector?: string;
  status: 'Completed' | 'Processing' | 'Pending' | 'Cancelled';
  assignedCourier?: string;
  notes?: string;
}

export interface Courier {
  id: string;
  name: string;
  phone: string;
  status: 'Active' | 'Idle' | 'Offline';
  vehicle: string;
  vehiclePlate: string;
  currentZone: string;
  currentLat: number; // For map visualization (0-100 relative scales)
  currentLng: number; // For map visualization (0-100 relative scales)
  activeTask?: string;
  completedCount: number;
}

export interface IndustryPartner {
  id: string;
  name: string;
  sector: 'Biodiesel' | 'Sabun / Wax' | 'Lilin Aromaterapi' | 'Kimia';
  allocatedVolume: number; // in Liters
  activeContracts: number;
  efficiency: number; // Percentage
  status: 'Aktif' | 'Siaga' | 'Kemitraan Baru';
}

export interface BudgetItem {
  no: number;
  component: string;
  cost: number;
}

export interface BudgetCategory {
  title: string;
  items: BudgetItem[];
  subtotal: number;
}

export interface TeamMember {
  name: string;
  nim: string;
  role: string;
}
