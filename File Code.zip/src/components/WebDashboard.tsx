/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BarChart3, RefreshCw, Users, Truck, Building2, ClipboardList, 
  Search, ArrowUpRight, CheckCircle, Clock, AlertTriangle, XCircle, 
  Download, Filter, Plus, Printer, ShieldAlert, Key, MapPin, 
  HelpCircle, Eye, Sparkles, TrendingUp, Info
} from 'lucide-react';
import { Transaction, Courier, IndustryPartner } from '../types';

interface WebDashboardProps {
  transactions: Transaction[];
  addTransaction: (tx: Transaction) => void;
  updateTxStatus: (id: string, status: Transaction['status']) => void;
  couriers: Courier[];
  updateCourierStatus: (id: string, status: Courier['status']) => void;
  industryPartners: IndustryPartner[];
  totalCollected: number;
  totalSampahCollected?: number;
}

export default function WebDashboard({ 
  transactions, 
  addTransaction, 
  updateTxStatus, 
  couriers, 
  updateCourierStatus, 
  industryPartners,
  totalCollected,
  totalSampahCollected = 12840
}: WebDashboardProps) {
  
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true); // default true for preview efficiency
  const [adminUsername, setAdminUsername] = useState('admin@ecosmart.id');
  const [adminPassword, setAdminPassword] = useState('SecretPassword123');
  const [activeMenu, setActiveMenu] = useState<string>('overview');
  
  // Local filter states
  const [txSearch, setTxSearch] = useState('');
  const [txFilterStatus, setTxFilterStatus] = useState<string>('all');
  const [selectedTxDetail, setSelectedTxDetail] = useState<Transaction | null>(null);

  // Users section states
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState('Courier');
  const [newUserZone, setNewUserZone] = useState('Zone B-15');

  // Helper formatting for Indonesian Rupiah & Number
  const formatRupiah = (value: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(value);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminUsername.trim() !== '' && adminPassword.length >= 6) {
      setIsLoggedIn(true);
    }
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) return;
    // Alert simulate and add
    alert(`Stakeholder "${newUserName}" berhasil ditambahkan sebagai "${newUserRole}" di ${newUserZone}!`);
    setShowAddUserModal(false);
    setNewUserName('');
  };

  // Printable receipt simulator
  const handlePrintCertificate = (tx: Transaction) => {
    const isOil = !tx.category || tx.category === 'Oil';
    const volumeLabel = isOil ? 'Volume Minyak' : 'Berat Sampah ';
    const unitLabel = tx.unit || (isOil ? 'Liter' : 'Kg');
    const systemCategory = isOil ? 'MINYAK JELANTAH (OIL HUB)' : 'BANK SAMPAH (WASTE BANK)';
    const printContent = `
      ======================================================
                  CERTIFICATE OF ECOLOGICAL CONTRIBUTION
                     ECOSMART SYSTEM - ${systemCategory}
      ======================================================
      ID Transaksi  : ${tx.id}
      Tanggal       : ${tx.date}
      Disumbangkan  : ${tx.clientName} (${tx.clientType})
      ${volumeLabel} : ${tx.volume} ${unitLabel}
      Poin Diperoleh: ${tx.points} Poin
      Lokasi Setor  : ${tx.location}
      Mitra Energi  : ${isOil ? 'PT Pertamina (Persero) Cirebon Hub' : 'Asosiasi Industri Daur Ulang Plastik'}
      
      Status        : ${tx.status.toUpperCase()}
      
      Melalui sumbangan ini, Anda telah berkontribusi mencegah
      kerusakan ekologis tanah serta mendorong sirkularitas 
      bahan baku ramah lingkungan. Terimakasih telah menjadi Pahlawan Bumi!
      ======================================================
    `;
    alert(printContent);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-slate-50 p-4">
        <div className="w-full max-w-md bg-white rounded-xl border border-slate-205 shadow-sm overflow-hidden p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mx-auto shadow-xs">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <h2 className="font-display font-extrabold text-2xl text-slate-800 tracking-tight">Admin Portal Login</h2>
            <p className="text-xs text-slate-400">Silakan login kepengurusan pusat Smart Oil System Indonesia</p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Email atau Username</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <span className="text-xs font-semibold font-mono">@</span>
                </span>
                <input
                  type="text"
                  required
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="w-full pl-8 pr-4 py-2.5 bg-slate-55 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                  placeholder="admin@smartoil.id"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Kata Sandi</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Key className="w-3.5 h-3.5" />
                </span>
                <input
                  type="password"
                  required
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full pl-8 pr-4 py-2.5 bg-slate-55 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition"
                  placeholder="••••••••••••"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-500">
                <input type="checkbox" defaultChecked className="rounded text-blue-600 focus:ring-blue-500" />
                <span>Simpan login saya</span>
              </label>
              <a href="#reset" className="text-blue-600 font-semibold hover:underline">Lupa sandi?</a>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition shadow-xs active:scale-95"
            >
              Masuk ke Dashboard
            </button>
          </form>

          <div className="border-t border-slate-100 pt-4 text-center">
            <span className="text-[10px] text-slate-400 font-mono">Secured by EcoShield Industrial Protocols</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 text-slate-800 animate-fade-in">
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs min-h-[750px] grid grid-cols-1 md:grid-cols-12 overflow-hidden">
        
        {/* Left Side Navigation (Cols 3) */}
        <div className="md:col-span-3 bg-slate-50 border-r border-slate-200 p-6 flex flex-col justify-between">
          <div className="space-y-6">
            
            {/* Header logo */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-emerald-600 text-white rounded-lg flex items-center justify-center font-display font-extrabold text-lg shadow-xs">
                E
              </div>
              <div>
                <h3 className="font-display font-extrabold text-sm tracking-tight text-slate-800">ECOSMART</h3>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Integrated Waste Portal</p>
              </div>
            </div>

            {/* Menu Links */}
            <div className="space-y-1">
              {[
                { id: 'overview', label: 'Dashboard Overview', icon: BarChart3 },
                { id: 'transactions', label: 'Halaman Transaksi', icon: ClipboardList, badge: transactions.length },
                { id: 'users', label: 'Stakeholders & Users', icon: Users },
                { id: 'logistics', label: 'Logistik & Kurir', icon: Truck, badge: couriers.filter(c => c.status === 'Active').length },
                { id: 'industries', label: 'Suplai Industri', icon: Building2 },
                { id: 'reports', label: 'Laporan & Dampak', icon: RefreshCw }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition ${
                    activeMenu === item.id 
                      ? 'bg-emerald-600 text-white shadow-xs' 
                      : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                      activeMenu === item.id ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

          </div>

          <div className="pt-6 border-t border-slate-200/60 text-xs space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-600 text-xs uppercase shadow-xs">
                AD
              </div>
              <div>
                <p className="font-semibold text-slate-700">Admin Utama</p>
                <p className="text-[10px] text-slate-400">admin@ecosmart.id</p>
              </div>
            </div>
            <button 
              onClick={() => setIsLoggedIn(false)}
              className="w-full py-1.5 border border-slate-200 hover:border-rose-300 hover:text-rose-600 hover:bg-rose-50/25 rounded-lg text-[10px] font-bold transition text-slate-500"
            >
              Log Keluar Portal
            </button>
          </div>
        </div>

        {/* Right Side Content Display (Cols 9) */}
        <div className="md:col-span-9 p-6 sm:p-8 overflow-y-auto max-h-[750px] space-y-6">
          
          {/* Active section header */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <p className="text-[10px] text-emerald-600 font-extrabold tracking-wider uppercase">Portal Pusat Pemantauan</p>
              <h2 className="font-display font-black text-xl sm:text-2xl text-slate-800 tracking-tight">
                {activeMenu === 'overview' && "Sistem Monitoring Real-Time"}
                {activeMenu === 'transactions' && "Daftar Audit Transaksi"}
                {activeMenu === 'users' && "Roster Stakeholder Terdaftar"}
                {activeMenu === 'logistics' && "Sistem Manajemen Rute & Kurir"}
                {activeMenu === 'industries' && "Distribusi Suplai ke Mitra Rekanan"}
                {activeMenu === 'reports' && "Analisis Statistik & Dampak Ekologis"}
              </h2>
            </div>
 
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse"></span>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest font-mono">Live Server</span>
            </div>
          </div>
 
          {/* SECTION: OVERVIEW / DASHBOARD */}
          {activeMenu === 'overview' && (
            <div className="space-y-6">
              
              {/* Counters */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Minyak Terkumpul</span>
                    <Building2 className="w-4 h-4 text-emerald-600" />
                  </div>
                  <p className="text-xl sm:text-2xl font-display font-black text-slate-800 tracking-tight">
                    {totalCollected.toLocaleString()} L
                  </p>
                  <span className="text-[9px] text-emerald-600 font-semibold flex items-center gap-0.5">
                    <TrendingUp className="w-3 h-3" /> +12.5% vs bulan lalu
                  </span>
                </div>
 
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Sampah Terkumpul</span>
                    <RefreshCw className="w-4 h-4 text-emerald-600" />
                  </div>
                  <p className="text-xl sm:text-2xl font-display font-black text-slate-800 tracking-tight">
                    {totalSampahCollected.toLocaleString()} Kg
                  </p>
                  <span className="text-[9px] text-emerald-600 font-semibold flex items-center gap-0.5">
                    <TrendingUp className="w-3 h-3" /> Ekonomi Sirkular Aktif
                  </span>
                </div>
 
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Jml Transaksi</span>
                    <ClipboardList className="w-4 h-4 text-emerald-600" />
                  </div>
                  <p className="text-xl sm:text-2xl font-display font-black text-slate-800 tracking-tight">
                    {transactions.length}
                  </p>
                  <span className="text-[9px] text-emerald-600 font-semibold flex items-center gap-0.5">
                    <TrendingUp className="w-3 h-3" /> Kontribusi meningkat
                  </span>
                </div>
 
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Kurir Tugas</span>
                    <Truck className="w-4 h-4 text-emerald-600" />
                  </div>
                  <p className="text-xl sm:text-2xl font-display font-black text-slate-800 tracking-tight">
                    {couriers.length}
                  </p>
                  <span className="text-[9px] text-emerald-600 font-semibold">Ready di Lapangan</span>
                </div>
 
              </div>

              {/* Central Chart & Regional Info Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Custom Stylised Web SVG Bar/Line Chart */}
                <div className="lg:col-span-8 bg-slate-50 border border-slate-100 rounded-xl p-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <div>
                      <h4 className="font-display font-bold text-sm text-slate-800">Tren Daur Ulang Bulanan Terintegrasi</h4>
                      <p className="text-[10px] text-slate-400 font-normal">Pemetaan sirkularitas sirkuit Solid (Kg) & Liquid (L) Waste</p>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold">
                      <span className="flex items-center gap-1 text-slate-600">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span> Minyak (L)
                      </span>
                      <span className="flex items-center gap-1 text-slate-600">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span> Sampah (Kg)
                      </span>
                    </div>
                  </div>

                  {/* SVG Line & Bar graph */}
                  <div className="h-44 flex items-end justify-between pt-4 px-2">
                    {[
                      { m: 'Jan', o: 4100, op: 40, w: 1800, wp: 42 },
                      { m: 'Feb', o: 4800, op: 47, w: 2100, wp: 49 },
                      { m: 'Mar', o: 6200, op: 60, w: 2900, wp: 67 },
                      { m: 'Apr', o: 8400, op: 81, w: 3200, wp: 74 },
                      { m: 'May', o: 9200, op: 89, w: 3800, wp: 88 },
                      { m: 'Jun', o: 12500, op: 100, w: 4300, wp: 100 }
                    ].map((bar, bIdx) => (
                      <div key={bIdx} className="flex flex-col items-center gap-1.5 w-[14%] group cursor-pointer">
                        <div className="flex gap-1 justify-center w-full h-28 relative items-end">
                          {/* Oil Bar */}
                          <div className="w-[42%] relative bg-slate-100 rounded-t-xs h-full flex items-end">
                            <div 
                              className="w-full bg-emerald-600 hover:bg-emerald-500 rounded-t-xs transition-all duration-500" 
                              style={{ height: `${bar.op}%` }}
                              title={`Minyak: ${bar.o} L`}
                            />
                          </div>
                          {/* Waste Bar */}
                          <div className="w-[42%] relative bg-slate-100 rounded-t-xs h-full flex items-end">
                            <div 
                              className="w-full bg-amber-500 hover:bg-amber-400 rounded-t-xs transition-all duration-500" 
                              style={{ height: `${bar.wp}%` }}
                              title={`Sampah: ${bar.w} Kg`}
                            />
                          </div>
                        </div>
                        <span className="text-[10px] font-semibold text-slate-400 group-hover:text-slate-700 transition">{bar.m}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Personnel Quick monitoring panel */}
                <div className="lg:col-span-4 bg-slate-50 border border-slate-100 rounded-xl p-5 space-y-4">
                  <h4 className="font-display font-bold text-sm text-slate-800">Status Tugas Kurir</h4>
                  
                  <div className="space-y-3 max-h-48 overflow-y-auto">
                    {couriers.map(courier => (
                      <div key={courier.id} className="flex items-center justify-between p-2.5 bg-white border border-slate-100 rounded-xl">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-600 shrink-0"></div>
                          <div>
                            <p className="text-xs font-bold text-slate-700">{courier.name}</p>
                            <p className="text-[9.5px] text-slate-400 font-mono">{courier.vehiclePlate}</p>
                          </div>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                          courier.status === 'Active' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-505'
                        }`}>
                          {courier.status === 'Active' ? 'Bertugas' : 'Istirahat'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Recent Transactions List Grid */}
              <div className="space-y-3">
                <h4 className="font-display font-bold text-sm text-slate-800">Setoran Terakhir yang Masuk</h4>
                
                <div className="overflow-x-auto rounded-xl border border-slate-100 bg-white">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-55 border-b border-slate-100 text-slate-500 font-semibold">
                      <tr>
                        <th className="p-3">Ref ID</th>
                        <th className="p-3">Nama Klien</th>
                        <th className="p-3">Kategori</th>
                        <th className="p-3 text-right">Kuantitas</th>
                        <th className="p-3">Lokasi Penjemputan</th>
                        <th className="p-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50 text-slate-600">
                      {transactions.slice(0, 4).map(tx => {
                        const isOil = !tx.category || tx.category === 'Oil';
                        return (
                          <tr key={tx.id} className="hover:bg-slate-50">
                            <td className="p-3 font-mono font-bold text-slate-800">{tx.id}</td>
                            <td className="p-3 font-semibold">
                              <div>
                                <span className="font-bold text-slate-705 block">{tx.clientName}</span>
                                <span className="bg-slate-100 text-slate-500 px-1.5 py-0.2 rounded text-[9px] font-mono font-bold">{tx.clientType}</span>
                              </div>
                            </td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.5 rounded text-[9.5px] font-bold ${
                                isOil ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                              }`}>
                                {isOil ? '💧 Minyak' : '📦 Sampah'}
                              </span>
                            </td>
                            <td className="p-3 text-right font-mono font-bold text-slate-800">{tx.volume} {tx.unit || (isOil ? 'L' : 'Kg')}</td>
                            <td className="p-3 truncate max-w-40">{tx.location}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold ${
                                tx.status === 'Completed' ? 'bg-emerald-50 text-emerald-700' :
                                tx.status === 'Processing' ? 'bg-amber-100 text-amber-700' :
                                'bg-slate-100 text-slate-500'
                              }`}>
                                {tx.status === 'Completed' ? 'Selesai' :
                                 tx.status === 'Processing' ? 'Diproses' : 'Menunggu'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}


          {/* SECTION: TRANSACTIONS LOGS */}
          {activeMenu === 'transactions' && (
            <div className="space-y-6">
              
              {/* Filter controls */}
              <div className="flex flex-wrap gap-3 items-center justify-between pb-2">
                <div className="relative w-full sm:w-64">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Cari transaksi..."
                    value={txSearch}
                    onChange={(e) => setTxSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 text-xs bg-slate-55 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 outline-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5" /> Filter Status:
                  </span>
                  <select
                    value={txFilterStatus}
                    onChange={(e) => setTxFilterStatus(e.target.value)}
                    className="bg-white border border-slate-201 border-slate-200 rounded-lg text-xs px-3 py-1.5 outline-none font-semibold text-slate-705 focus:border-blue-600"
                  >
                    <option value="all">Semua Status</option>
                    <option value="Completed">Completed (Selesai)</option>
                    <option value="Processing">Processing (Diproses)</option>
                    <option value="Pending">Pending (Baru)</option>
                  </select>
                </div>
              </div>

              {/* Core Logs table */}
              <div className="overflow-x-auto rounded-xl border border-slate-100 bg-white">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-55 border-b border-slate-100 text-slate-500 font-semibold">
                    <tr>
                      <th className="p-3">Ref ID</th>
                      <th className="p-3">Tanggal</th>
                      <th className="p-3">Pemasok</th>
                      <th className="p-3">Kategori</th>
                      <th className="p-3 text-right">Kuantitas</th>
                      <th className="p-3">Ganjaran Poin</th>
                      <th className="p-3">Status Rantai</th>
                      <th className="p-3 text-right">Opsi Tindakan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-slate-600">
                    {transactions
                      .filter(tx => {
                        const matchesSearch = tx.clientName.toLowerCase().includes(txSearch.toLowerCase()) || tx.id.toLowerCase().includes(txSearch.toLowerCase());
                        if (txFilterStatus !== 'all' && tx.status !== txFilterStatus) return false;
                        return matchesSearch;
                      })
                      .map(tx => {
                        const isOil = !tx.category || tx.category === 'Oil';
                        return (
                          <tr key={tx.id} className="hover:bg-slate-50">
                            <td className="p-3 font-mono font-bold text-slate-800">{tx.id}</td>
                            <td className="p-3 text-slate-400">{tx.date}</td>
                            <td className="p-3">
                              <div>
                                <p className="font-bold text-slate-705">{tx.clientName}</p>
                                <p className="text-[10px] text-slate-400">{tx.clientType}</p>
                              </div>
                            </td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.5 rounded text-[9.5px] font-bold ${
                                isOil ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                              }`}>
                                {isOil ? '💧 Minyak' : '📦 Sampah'}
                              </span>
                            </td>
                            <td className="p-3 font-mono font-black text-slate-800 text-right pr-6">{tx.volume} {tx.unit || (isOil ? 'L' : 'Kg')}</td>
                            <td className="p-3">
                              <span className="text-emerald-600 font-bold font-mono">+{tx.points} pts</span>
                            </td>
                            <td className="p-3">
                              <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold ${
                                tx.status === 'Completed' ? 'bg-emerald-50 text-emerald-700' :
                                tx.status === 'Processing' ? 'bg-amber-100 text-amber-700' :
                                'bg-slate-100 text-slate-500'
                              }`}>
                                {tx.status}
                              </span>
                            </td>
                            <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                              {tx.status !== 'Completed' && (
                                <button
                                  onClick={() => updateTxStatus(tx.id, 'Completed')}
                                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold"
                                >
                                  Selesaikan
                                </button>
                              )}
                              <button
                                onClick={() => handlePrintCertificate(tx)}
                                className="px-2 py-1 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-lg text-[10px] icon flex items-center gap-1 inline-flex"
                              >
                                <Printer className="w-3 h-3" /> Cetak
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>

            </div>
          )}


          {/* SECTION: USERS */}
          {activeMenu === 'users' && (
            <div className="space-y-6">
              
              <div className="flex justify-between items-center bg-slate-50 p-4 border border-slate-100 rounded-xl">
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-800">Daftar Anggota Sistem</h4>
                  <p className="text-[10px] text-slate-400">Pengurusan akun kurir, regional manager, and tim pengelola data.</p>
                </div>
                <button
                  onClick={() => setShowAddUserModal(true)}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs active:scale-95"
                >
                  <Plus className="w-4 h-4" /> Tambah Roster
                </button>
              </div>

              {/* Roster profiles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'Sarah Jenkins', role: 'Regional Manager (Solo)', email: 'sarah.j@smartoil.id', status: 'Online', phone: '+62-812-3329-1111' },
                  { name: 'Marcus Thorne', role: 'Senior Dispatcher Courier', email: 'marcus.t@smartoil.id', status: 'On Route', phone: '+62-811-9231-4455' },
                  { name: 'Elena Rodriguez', role: 'Partner Coordinator Liaison', email: 'elena.r@smartoil.id', status: 'Online', phone: '+62-813-8822-7711' },
                  { name: 'David Chang', role: 'System Admin Coordinator', email: 'david.c@smartoil.id', status: 'Online', phone: '+62-812-7733-9922' }
                ].map((usr, uIdx) => (
                  <div key={uIdx} className="bg-slate-50 hover:bg-slate-100/55 border border-slate-150 p-4 rounded-xl transition space-y-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-slate-200 text-slate-600 font-bold text-xs flex items-center justify-center shadow-xs">
                          {usr.name.split(' ').map(n=>n[0]).join('')}
                        </div>
                        <div>
                          <h5 className="font-display font-extrabold text-xs text-slate-850">{usr.name}</h5>
                          <p className="text-[10px] text-slate-400">{usr.role}</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[9px] font-bold">
                        {usr.status}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-slate-200/50 flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>{usr.email}</span>
                      <span>{usr.phone}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add User Modal Simulation */}
              {showAddUserModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
                  <div className="bg-white rounded-xl border border-slate-100 p-6 max-w-sm w-full space-y-4 shadow-sm">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                      <h4 className="font-display font-extrabold text-sm text-slate-800">Registrasi Roster Baru</h4>
                      <button onClick={() => setShowAddUserModal(false)} className="text-slate-400 font-bold">✕</button>
                    </div>

                    <form onSubmit={handleAddUser} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Nama Lengkap</label>
                        <input
                          type="text"
                          required
                          placeholder="Contoh: Budi Santoso"
                          value={newUserName}
                          onChange={(e) => setNewUserName(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-1 focus:ring-blue-600"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Jabatan Dinas</label>
                        <select
                          value={newUserRole}
                          onChange={(e) => setNewUserRole(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none"
                        >
                          <option value="Courier">Kurir Lapangan (Courier)</option>
                          <option value="Liaison Office">Koordinator Klien (Liaison)</option>
                          <option value="System Manager">Administrator Wilayah</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Zona Operasi Utama</label>
                        <input
                          type="text"
                          required
                          value={newUserZone}
                          onChange={(e) => setNewUserZone(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                        />
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setShowAddUserModal(false)}
                          className="w-1/2 py-2 text-xs border border-slate-200 text-slate-500 rounded-lg"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          className="w-1/2 py-2 text-xs bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow-xs active:scale-95"
                        >
                          Daftarkan
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

            </div>
          )}


          {/* SECTION: LOGISTICS (COURIERS & MAPS) */}
          {activeMenu === 'logistics' && (
            <div className="space-y-6">
              
              {/* Radar Tracking Map Simulation */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-5 space-y-4">
                <div className="flex justify-between items-center flex-wrap gap-2">
                  <div>
                    <h4 className="font-display font-bold text-sm text-slate-800">Sistem Pemetaan Logistik GPS (Zone B-12)</h4>
                    <p className="text-[10px] text-slate-400">Koordinat armada truk tangki penjemputan minyak secara langsung di lapangan.</p>
                  </div>
                  <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md font-bold">Rute Terkalkulasi Jarak Terpendek</span>
                </div>

                {/* Simulated Geolocation Screen Grid */}
                <div className="h-52 bg-slate-900 rounded-xl relative overflow-hidden border border-slate-850 shadow-inner flex items-center justify-center">
                  
                  {/* Map grids */}
                  <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 opacity-[0.06] pointer-events-none">
                    {Array.from({ length: 24 }).map((_, i) => (
                      <div key={i} className="border border-white"></div>
                    ))}
                  </div>

                  {/* Radiating tracking circle in center */}
                  <div className="absolute w-28 h-28 rounded-full border border-blue-500/10 pointer-events-none animate-ping"></div>

                  {/* Stylized vector roads */}
                  <div className="absolute left-0 right-0 h-1 bg-white/[0.04] top-1/2 pointer-events-none"></div>
                  <div className="absolute left-1/3 top-0 bottom-0 w-1 bg-white/[0.04] pointer-events-none"></div>
                  <div className="absolute left-2/3 top-0 bottom-0 w-1 bg-white/[0.04] pointer-events-none"></div>

                  {/* Courier Pins dynamically overlayed */}
                  {couriers.map((courier, cIdx) => (
                    <div 
                      key={courier.id} 
                      className="absolute transition-all duration-1000 flex flex-col items-center cursor-pointer group"
                      style={{ left: `${courier.currentLat}%`, top: `${courier.currentLng}%` }}
                    >
                      <div className="bg-blue-600 ring-4 ring-blue-500/20 text-white rounded-full p-1 shadow-md hover:bg-blue-500">
                        <Truck className="w-3.5 h-3.5" />
                      </div>
                      <div className="absolute top-7 bg-slate-850 border border-slate-75 text-slate-300 px-2 py-0.5 rounded text-[8.5px] font-mono leading-none shadow-md hidden group-hover:block whitespace-nowrap z-10">
                        {courier.name} ({courier.vehiclePlate}) - {courier.status}
                      </div>
                    </div>
                  ))}

                  {/* Customer Pickup Request Pins */}
                  <div className="absolute left-[38%] top-[25%] flex flex-col items-center">
                    <div className="bg-amber-500 ring-4 ring-amber-500/25 text-white rounded-full p-1 animate-bounce">
                      <MapPin className="w-3.5 h-3.5" />
                    </div>
                    <span className="bg-slate-900 border border-slate-800 text-[8px] text-amber-500 px-1.5 py-0.2 rounded mt-1 font-bold whitespace-nowrap">Restoran Padang (Antrian)</span>
                  </div>

                  <span className="absolute bottom-3 left-3 text-[9px] font-mono text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">GPS Status: Presisi +/- 2 Meter</span>
                </div>
              </div>

              {/* Courier Inventory Monitoring Rows */}
              <div className="space-y-3">
                <h4 className="font-display font-bold text-sm text-slate-800">Kargo Tangki Kurir Terarsip</h4>
                
                <div className="space-y-2">
                  {couriers.map(courier => {
                    const progressLiters = Math.min(100, Math.floor((courier.completedCount / 5) * 100)) || 15;
                    return (
                      <div key={courier.id} className="flex flex-wrap items-center justify-between p-4 bg-white border border-slate-100 rounded-xl gap-4">
                        <div className="space-y-0.5">
                          <p className="font-display font-extrabold text-xs text-slate-800">{courier.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono tracking-wider">{courier.vehicle} • Pelat {courier.vehiclePlate}</p>
                        </div>

                        <div className="w-full sm:w-52 space-y-1">
                          <div className="flex justify-between text-[9.5px] font-mono text-slate-500">
                            <span>Isi Tangki Kargo</span>
                            <span className="font-bold text-slate-700">{progressLiters}% (Setara {Math.floor(progressLiters * 2.5)}L)</span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div className="bg-blue-600 h-full rounded-full" style={{ width: `${progressLiters}%` }} />
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            courier.status === 'Active' ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-400'
                          }`}>
                            {courier.status === 'Active' ? 'Zona Aktif: ' + courier.currentZone : 'Siaga Pendulum'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          )}


          {/* SECTION: INDUSTRIES */}
          {activeMenu === 'industries' && (
            <div className="space-y-6">
              
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-5 flex flex-col md:flex-row gap-5 items-center justify-between">
                <div className="space-y-1 text-center md:text-left">
                  <span className="text-[9px] bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-md">Rantai Sirkulasi Industri</span>
                  <h4 className="font-display font-extrabold text-sm text-slate-800 mt-1">Draf Alokasi Minyak Mentah Pertamina</h4>
                  <p className="text-[11px] text-slate-400">Total volume minyak jelantah yang disalurkan ke reaktor biodiesel dari pengepul Smart Oil.</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="p-3 bg-white rounded-xl border border-slate-150 text-center min-w-24">
                    <p className="text-[9px] text-slate-400 uppercase font-semibold">Toral Alokasi</p>
                    <p className="font-mono text-base font-bold text-slate-800">{(totalCollected * 0.65).toFixed(0)} L</p>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-150 text-center min-w-24">
                    <p className="text-[9px] text-slate-400 uppercase font-semibold">Siap Ambil</p>
                    <p className="font-mono text-base font-bold text-blue-600">{(totalCollected * 0.35).toFixed(0)} L</p>
                  </div>
                </div>
              </div>

              {/* Partners lists */}
              <div className="space-y-3">
                <h4 className="font-display font-bold text-sm text-slate-800">Roster Rekanan Energi Hijau Berlisensi</h4>
                
                <div className="space-y-3">
                  {industryPartners.map(partner => (
                    <div key={partner.id} className="bg-white border border-slate-100 hover:border-slate-200 p-5 rounded-xl transition grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                      
                      <div className="md:col-span-4 flex items-center gap-3">
                        <div className="p-2 bg-slate-50 text-slate-600 rounded-xl border border-slate-150">
                          <Building2 className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <h5 className="font-display font-extrabold text-xs text-slate-800">{partner.name}</h5>
                          <p className="text-[10px] text-slate-400">Sektor Rantai: {partner.sector}</p>
                        </div>
                      </div>

                      <div className="md:col-span-3 text-left md:text-center text-xs">
                        <p className="text-[9px] text-slate-400 uppercase font-bold">Volume Terkontrak</p>
                        <p className="font-mono font-bold text-slate-705 mt-0.5">{partner.allocatedVolume.toLocaleString()} Liter</p>
                      </div>

                      <div className="md:col-span-3 text-left md:text-center text-xs">
                        <p className="text-[9px] text-slate-400 uppercase font-bold">Rasio Efisiensi Konversi</p>
                        <div className="flex items-center justify-start md:justify-center gap-1.5 mt-0.5 font-semibold text-blue-700">
                          <TrendingUp className="w-3.5 h-3.5" />
                          <span>{partner.efficiency}% Olahan Net</span>
                        </div>
                      </div>

                      <div className="md:col-span-2 text-right">
                        <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-blue-50 text-blue-700">
                          {partner.status}
                        </span>
                      </div>

                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}


          {/* SECTION: REPORTS */}
          {activeMenu === 'reports' && (
            <div className="space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                <div className="p-4 bg-emerald-600 rounded-xl text-white space-y-1 shadow-sm">
                  <p className="text-[9px] uppercase font-bold tracking-wider opacity-80">Minyak Terselamatkan</p>
                  <p className="font-display font-black text-xl">{totalCollected.toLocaleString()} Liter</p>
                  <p className="text-[10px] opacity-90">Mencegah pencemaran miliaran liter ekosistem air tawar.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-1">
                  <p className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Sampah Padat Organik & Anorganik</p>
                  <p className="font-display font-black text-xl text-emerald-800">{totalSampahCollected.toLocaleString()} Kg</p>
                  <p className="text-[10.5px] text-slate-500 font-medium">Limbah yang dialihkan langsung dari TPA lokal.</p>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-1">
                  <p className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Dampak Emisi CO2 Ditekan</p>
                  <p className="font-display font-black text-xl text-emerald-850 text-emerald-700">
                    {((totalCollected * 0.00244) + (totalSampahCollected * 0.0012)).toFixed(2)} Ton
                  </p>
                  <p className="text-[10.5px] text-slate-550 text-emerald-600 font-semibold font-medium">Setara menyuburkan {(((totalCollected * 0.00244) + (totalSampahCollected * 0.0012)) * 45).toFixed(0)} pohon pelindung baru.</p>
                </div>

              </div>

              {/* Informative description regarding the report */}
              <div className="bg-emerald-50/15 border border-emerald-100 rounded-xl p-6 space-y-4">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-sm text-slate-800">Catatan Analisis Dampak Ekologi</h4>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      Kombinasi pengelolaan limbah cair berupa minyak jelantah dan limbah padat anorganik kering di EcoSmart System mempercepat tercapainya pilar pembangunan berkelanjutan tingkat kota. Berdasarkan rujukan standardisasi sirkularitas, penanganan digital terintegrasi ini mampu meningkatkan kepatuhan daur ulang warga hingga sebesar 84.5% melalui insentif poin yang adekuat.
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-emerald-100/60 flex flex-wrap gap-2.5">
                  <button 
                    onClick={() => alert(`Format PDF Laporan Dampak & Analisis Ekologis Semester 1 (EcoSmart_Impact_H1_2026.pdf) berhasil digenerasi!`)}
                    className="px-4 py-2 bg-emerald-650 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 active:scale-95 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" /> Unduh Laporan PDF (EcoSmart)
                  </button>
                  <button 
                    onClick={() => alert(`Data log perputaran sirkularitas insentif (EcoSmart_Audit_Log_Reclamation.xlsx) berhasil diekspor!`)}
                    className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
                  >
                    <ClipboardList className="w-3.5 h-3.5 text-slate-400" /> Ekspor File Excel
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
